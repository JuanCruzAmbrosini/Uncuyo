import React from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './src/assets/App.jsx'
import './src/assets/index.css'

createRoot(document.getElementById('root')).render(
    <React.Fragment>
        <App />
    </React.Fragment>
)
