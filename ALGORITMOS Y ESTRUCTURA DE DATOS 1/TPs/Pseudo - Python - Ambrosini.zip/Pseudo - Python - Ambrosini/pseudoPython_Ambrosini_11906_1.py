from algo1 import *

a = input_int("Ingrese un valor entero: ")
print("Valor ingresado: ", a)

b = input_real("Ingrese un segundo valor real: ")
print("Valor ingresado: ", b)

c = a + b

print("El resultado de la suma de ambos valores es de: ", c)