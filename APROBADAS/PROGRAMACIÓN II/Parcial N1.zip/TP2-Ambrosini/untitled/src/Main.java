/*
Una clase abstracta llamada JUEGO, que tiene un único atributo, que es: cantidad de jugadores (constante con valor 2)

Una clase llamada TABLERO, que contiene como atributos un arraylist de 32 objetos de tipo FICHA, presentando agregación con TABLERO.

El comportamiento Iniciar() de la clase TABLERO, inicia el juego, activando una movida para alguna ficha a través del arreglo.

La clase FICHA tiene como atributos:

Un par de coordenadas enteras x, y que representan la posición de la ficha en el tablero. Un color, que puede ser blanco o negro.
Un comportamiento llamado Mover() que recibe como parámetros las coordenadas a dónde se desea trasladar la ficha y produce el desplazamiento de la pieza en el tablero.

Defina los constructores que sean necesarios en cada clase.
La clase Jugador deriva de Persona, que es abstracta. Persona tiene como único atributo a NickName y Jugador además tiene el atributo puntaje.

Defina un main() que muestre la utilización de las clases definidas previamente y la activación de
 los métodos que corresponda para proveer un menú de actividades que les permita cargar las jugadas
  de cada jugador en el tablero e ir modificando la posición de las fichas en el tablero hasta que se decida terminar.*/


import entities.Ficha;
import entities.Jugador;
import entities.Tablero;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in).useDelimiter("\n");
        boolean flag = true;
        int coordenadaEnX;
        int coordenadaEnY;
        String seguir;

        Tablero tablero = new Tablero();

        System.out.println(tablero.toString());

        Jugador jugador1 = new Jugador();
        Jugador jugador2 = new Jugador();

        while (flag){

            for (int i = 0; i <= 1; i++){

                System.out.println("Turno de jugador " + i);
                System.out.println("Ingrese las coordenadas de la ficha que desea mover: ");
                System.out.println("Coordenada en x: ");
                coordenadaEnX = scanner.nextInt();
                System.out.println("Coordenada en Y: ");
                coordenadaEnY = scanner.nextInt();
                System.out.println(coordenadaEnY);

                Ficha fichaElegida = tablero.buscarFicha(coordenadaEnX,coordenadaEnY);

                if (fichaElegida != null){

                    fichaElegida.moverFicha();

                } else {

                    System.out.println("No se encontró la ficha elegida.");

                }


            }

            System.out.println("Desea continuar? (s/n)");
            seguir = scanner.next();

            if (seguir.equalsIgnoreCase("s")){

                flag = true;

            } else if (seguir.equalsIgnoreCase("n")){

                flag = false;

            } else {

                System.out.println("Ingrese un valor válido.");

            }


        }

    }
}