package entities;

import java.util.ArrayList;

public class Tablero {

    private ArrayList<Ficha> listaFichas;

    public Tablero() {

        listaFichas = new ArrayList<Ficha>();

        for (int i = 0 ; i <= 1; i++){

            for (int j = 0; j <= 7; j++ ){

                Ficha ficha = new Ficha();

                ficha.setCoordenadaX(i);
                ficha.setCoordenadaY(j);
                ficha.setColor("Blanco");

                listaFichas.add(ficha);

            }

        }

        for (int i = 6; i <= 7; i++){

            for (int j = 0; j <= 7; j++ ){

                Ficha ficha = new Ficha();

                ficha.setCoordenadaX(i);
                ficha.setCoordenadaY(j);
                ficha.setColor("negro");

                listaFichas.add(ficha);

            }

        }

    }

    public ArrayList<Ficha> listaFichas() {
        return listaFichas;
    }

    public Tablero setListaFichas(ArrayList<Ficha> listaFichas) {
        this.listaFichas = listaFichas;
        return this;
    }

    @Override
    public String toString() {
        return "Tablero{" +
                "listaFichas=" + listaFichas.toString() +
                "} \n ";
    }

    public Ficha buscarFicha(int coordenadaX, int coordenadaY) {

        Ficha fichaElegida = null;

        for (Ficha ficha : listaFichas) {

            if (ficha.coordenadaX() == coordenadaX && ficha.coordenadaY() == coordenadaY) {

                fichaElegida = ficha;

            }

        }

        return fichaElegida;

    }

}
