package entities;

/*Un par de coordenadas enteras x, y que representan la posición de la ficha en el tablero. Un color, que puede ser blanco o negro.
Un comportamiento llamado Mover() que recibe como parámetros las coordenadas a dónde se desea trasladar la ficha y produce el desplazamiento de la pieza en el tablero*/

import java.util.Scanner;

public class Ficha {

    Scanner scanner = new Scanner(System.in).useDelimiter("\n");

    private int coordenadaX;
    private int coordenadaY;
    private String color;

    public Ficha() {

    }

    public int coordenadaX() {
        return coordenadaX;
    }

    public Ficha setCoordenadaX(int coordenadaX) {
        this.coordenadaX = coordenadaX;
        return this;
    }

    public int coordenadaY() {
        return coordenadaY;
    }

    public Ficha setCoordenadaY(int coordenadaY) {
        this.coordenadaY = coordenadaY;
        return this;
    }

    public String color() {
        return color;
    }

    public Ficha setColor(String color) {
        this.color = color;
        return this;
    }

    public void moverFicha(){

        System.out.println("Ingrese la posición en x para la ficha.");
        coordenadaX = scanner.nextInt();

        System.out.println("Ingrese la posición nueva en y para la ficha");
        coordenadaY = scanner.nextInt();

    }

    @Override
    public String toString() {
        return "Ficha{" +
                ", coordenadaX=" + coordenadaX +
                ", coordenadaY=" + coordenadaY +
                ", color='" + color + '\'' +
                '}';
    }
}
