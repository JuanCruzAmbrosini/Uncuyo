package entities;

import java.util.Scanner;

public class Jugador extends Persona  {

    Scanner scanner = new Scanner(System.in).useDelimiter("\n");
    private int puntaje;

    public Jugador() {

        puntaje = 0;

    }

    public int puntaje() {
        return puntaje;
    }

    public Jugador setPuntaje(int puntaje) {
        this.puntaje = puntaje;
        return this;
    }
}
