package entities;

import java.util.Scanner;

public abstract class Persona {


    Scanner scanner = new Scanner(System.in).useDelimiter("\n");
    private String NickName;

    public Persona() {

        System.out.println("Ingrese el nombre del jugador.");
        NickName = (scanner.next());

    }

    public String NickName() {
        return NickName;
    }

    public Persona setNickName(String nickName) {
        NickName = nickName;
        return this;
    }
}
