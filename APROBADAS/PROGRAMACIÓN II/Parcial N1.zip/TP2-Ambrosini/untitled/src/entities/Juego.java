package entities;

public abstract class Juego {

    private final int cantidadDeJugadores;

    public Juego() {
        this.cantidadDeJugadores = 2;
    }

}
