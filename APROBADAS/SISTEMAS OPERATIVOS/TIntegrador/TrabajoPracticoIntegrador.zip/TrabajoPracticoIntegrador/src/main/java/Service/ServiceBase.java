/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.util.logging.Logger;

/**
 *
 * @author asamsu
 */
public abstract class ServiceBase {
    protected final Logger logger = Logger.getLogger(this.getClass().getName());
}
