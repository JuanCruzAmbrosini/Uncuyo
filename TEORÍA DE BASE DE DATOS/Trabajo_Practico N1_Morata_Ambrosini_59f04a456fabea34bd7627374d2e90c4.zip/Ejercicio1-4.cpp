#include <iostream>
#include <vector>
#include <cmath>
#include <thread>
#include <sys/time.h>
#include <iomanip>

using namespace std;

void calculo_mono_hilo(long long int n, vector<long long int>& resultados) {

    if (n >= 2) resultados.push_back(2); // Agrega el 2 a los primos
    
    // Empieza en un número impar mayor a 2 y salta de dos en dos ya que todo
    // número par NO es primo
    for (long long int i = 3; i <= n; i += 2) { 

        bool es_primo = true; // Supone que es primo hasta que se demuestre lo contrario

        for (long long int p : resultados) {
            if (p * p > i) break; // Ponemos como límite la raíz del número

            // Si el módulo es cero, es divisor del número i
            if (i % p == 0) {
                es_primo = false;
                break;
            }
        }
        if (es_primo) resultados.push_back(i); // Agrega el número primo al final del vector de resultados
    }
}


void calculo_multi_hilo(long long int start, long long int end, const vector<long long int>& base_primos, vector<long long int>& resultados_locales) {
   
    if (start % 2 == 0) start++; // Garantiza empezar en un número impar
    
    for (long long int i = start; i <= end; i += 2) {

        bool es_primo = true;

        for (long long int p : base_primos) {
            if (p * p > i) break; 
            if (i % p == 0) {
                es_primo = false;
                break;
            }
        }
        if (es_primo) resultados_locales.push_back(i);
    }
}

int main() {
    long long int N;
    int cant_hilos;
    
    cout << "Ingrese el limite N: ";
    cin >> N;
    cout << "Ingrese la cantidad de hilos a utilizar: ";
    cin >> cant_hilos;

    timeval t1,t2;
    gettimeofday(&t1,NULL);

    if(cant_hilos == 1){

        vector<long long int> primos_secuenciales;
        calculo_mono_hilo(N, primos_secuenciales);
        
        cout << "Primos encontrados: " << primos_secuenciales.size() << endl;
    }
    else {
    
        // Establecemos una base de primos para poder calcular todos los demás en paralelo
        long long int limite_base = sqrt(N);
        vector<long long int> base_primos;
        calculo_mono_hilo(limite_base, base_primos);

        vector<thread> hilos(cant_hilos);
        vector<vector<long long int>> resultados_por_hilo(cant_hilos);
        
        long long int rango_restante = N - limite_base;
        long long int paso = rango_restante / cant_hilos;

        for (int i = 0; i < cant_hilos; i++) {
            long long int start = limite_base + 1 + (i * paso);
            long long int end = (i == cant_hilos - 1) ? N : start + paso - 1;
            
            hilos[i] = thread(calculo_multi_hilo, start, end, cref(base_primos), ref(resultados_por_hilo[i]));
        }

        for (int i = 0; i < cant_hilos; i++) {
            if (hilos[i].joinable()) {
                hilos[i].join();
            }
        }

        // Fase C: Ensamblar los resultados
        vector<long long int> primos_multihilo = base_primos;
        for (int i = 0; i < cant_hilos; i++) {
            // Insertamos el vector local de cada hilo al final del vector principal
            primos_multihilo.insert(primos_multihilo.end(), resultados_por_hilo[i].begin(), resultados_por_hilo[i].end());
        }
        cout << "Primos encontrados: " << primos_multihilo.size() << endl;
        cout << "Los 10 mayores numeros primos son:" << endl;
        
        int total_encontrados = primos_multihilo.size();
        int a_mostrar = min(10, total_encontrados);
        
        for (int i = total_encontrados - a_mostrar; i < total_encontrados; i++) {
            cout << primos_multihilo[i] << " ";
        }
        cout << endl;
    }
        
    gettimeofday(&t2, NULL);

    cout << "El tiempo de ejecución fue: " << double(t2.tv_sec-t1.tv_sec) + double(t2.tv_usec - t1.tv_usec)/1000000 << endl;

    return 0;
}