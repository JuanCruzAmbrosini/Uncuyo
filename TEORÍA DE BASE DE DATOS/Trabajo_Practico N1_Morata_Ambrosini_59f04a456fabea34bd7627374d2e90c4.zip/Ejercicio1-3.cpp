#include <sys/time.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include <thread>

using namespace std;

void print_esquinas(const vector<float>& matriz, int n) {
    cout << fixed << setprecision(4);
    cout << matriz[0] << "\t\t...\t" << matriz[n - 1] << endl;
    cout << "...\t\t...\t..." << endl;
    cout << matriz[(n - 1) * n] << "\t...\t" << matriz[(n - 1) * n + (n - 1)] << endl;
}

void calcular_matriz(const vector<float>& matriz_A, const vector<float>& matriz_B, vector<float>& matriz_R, int n, int start, int end) {
    int b = 64; 
    for (int i0 = start; i0 < end; i0 += b) {
        int i_max = (i0 + b < end) ? i0 + b : end;
        for (int k0 = 0; k0 < n; k0 += b) {
            int k_max = (k0 + b < n) ? k0 + b : n;
            for (int j0 = 0; j0 < n; j0 += b) {
                int j_max = (j0 + b < n) ? j0 + b : n;
                
                for (int i = i0; i < i_max; i++) {
                    for (int k = k0; k < k_max; k++) {
                        float a_ik = matriz_A[i * n + k];
                        for (int j = j0; j < j_max; j++) {
                            matriz_R[i * n + j] += a_ik * matriz_B[k * n + j];
                        }
                    }
                }
            }
        }
    }
}

int main() {
    int n;
    int cant_hilos;
    cout << "Ingrese el tamaño N de las matrices (N*N): ";
    cin >> n;
    cout << "Ingrese la cantidad de hilos a implementar (como máximo " << n << " ): ";
    cin >> cant_hilos;
        
    vector<float> matriz_A(n * n, 0.1f);
    vector<float> matriz_B(n * n, 0.2f);
    vector<float> matriz_R(n * n, 0.0f);

    cout << "\nCalculando multiplicación de " << n << "x" << n << "..." << endl;

    timeval t1,t2;
    gettimeofday(&t1,NULL);

    if(cant_hilos == 1){
        calcular_matriz(matriz_A, matriz_B, matriz_R, n, 0, n);
    } else {
        vector<thread> hilos(cant_hilos);
        int step = n / cant_hilos;

        for (int i = 0; i < cant_hilos; i++) {
            int start = i * step;
            int end = (i == cant_hilos - 1) ? n : (i + 1) * step;
            hilos[i] = thread(calcular_matriz, std::ref(matriz_A), std::ref(matriz_B), std::ref(matriz_R), n, start, end);
        }

        for(int i = 0; i < cant_hilos; i++){
            if (hilos[i].joinable()) {
                hilos[i].join();
            }
        }
    }
    
    double sumatoria_total = 0;
    for (float valor : matriz_R) {
        sumatoria_total += valor;
    }

    cout << "\nEsquinas de la Matriz Resultante:" << endl;
    print_esquinas(matriz_R, n);
    cout << "\nSumatoria total de elementos: " << sumatoria_total << endl;

    gettimeofday(&t2, NULL);
    cout << "El tiempo de ejecución fue: " << double(t2.tv_sec-t1.tv_sec) + double(t2.tv_usec - t1.tv_usec)/1000000 << endl;

    return 0;
}