#include <bits/types/struct_timeval.h>
#include <cstddef>
#include <iostream>
#include <cmath>
#include <iomanip> 
#include <ostream>
#include <thread>
#include <mutex>   
#include <sys/time.h>
using namespace std;

int terminos = 100000000;   
long double suma_total = 0.0;
mutex mtx_suma;  

void calcular_terminos(int inicio, int fin, double num){
    long double suma_parcial = 0;

    for (double i = inicio; i < fin; i++) {
        suma_parcial += pow(((num-1)/(num+1)), 2*i+1) /(2*i+1) ;
    }

    mtx_suma.lock();
    suma_total += suma_parcial; 
    mtx_suma.unlock();
}

int main(){
    double num;
    int hilos;
    const int maxHilos = 4; 
    
    cout << "Ingrese el número a evaluar: ";
    cin >> num;
    cout << "Ingrese cuantos hilos utilizar: ";
    cin >> hilos;

    while (hilos < 1 || hilos > maxHilos) {
        cout << "Cantidad de hilos inválida, debe ingresar entre 1 y " << maxHilos << ": ";
        cin >> hilos;
    }


    timeval t1,t2;
    gettimeofday(&t1,NULL);
    thread arreglo_hilos[maxHilos]; 

    for (int i = 0; i < hilos; i++) {
        arreglo_hilos[i] = thread(calcular_terminos, i * (terminos/hilos), (i+1) * (terminos/hilos), num);
    }
    
    for (int i = 0; i < hilos; i++) {
        if(arreglo_hilos[i].joinable()){
            arreglo_hilos[i].join();
        }
    }
    
    suma_total *= 2;
    cout << "El resultado de la suma es: " << setprecision(15) << suma_total << endl;
    
    gettimeofday(&t2, NULL);

    cout << "El tiempo de ejecución fue: " << double(t2.tv_sec-t1.tv_sec) + double(t2.tv_usec - t1.tv_usec)/1000000 << endl;

    return 0;
}