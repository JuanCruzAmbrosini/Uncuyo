#include <functional>
#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <vector>
#include <sys/time.h>



using namespace std;

vector<string> ingresar_patrones(string nombre_archivo_patrones){

    ifstream archivo(nombre_archivo_patrones);
    string linea_actual;
    vector<string> patrones;


    if (archivo.is_open()) { //Asegura que el archivo sea abierto
        
        //Al detectar un salto de linea guarda lo escaneado y eso se ingresa a un
        //vector que contendrá todos los patrones
        while (getline(archivo, linea_actual)) {
            
            patrones.push_back(linea_actual);
        }
        archivo.close();
    }
    //Devuelve un vector con todos los patrones (en orden de aparición en el archivo)
    return patrones;
}

// Declaramos que esta función usará un tipo de dato genérico llamado "T"
template <typename T>

// Reemplazamos <string> por <T> y usamos const reference (&)
void print_vector(const vector<T>& vector) {

    int size = vector.size();

    if (size == 0) {
        cout << "El vector ingresado está vacío" << endl;
    }
    else {
        // Recorre el vector ingresado e imprime todos sus elementos
        for(int i = 0; i < size; i++) {
            cout << i << " : " << vector.at(i) << endl;
        }
    }
}

// Función de búsqueda que solo usa un hilo
void buscar_patrones_mono_hilo(string nombre_archivo, vector<string> patrones){

    ifstream text;
    string data;

    int size = patrones.size();
    int contador = 0;
    int pos = 0;

    text.open(nombre_archivo);


    getline(text, data);

    for (int i = 0; i<size; i++) {

        //Si encuentra una coincidencia, cambia la variable pos a la posición siguiente
        //de la última coincidencia y aumenta el contador en uno
        while ((pos = data.find(patrones.at(i),pos)) != string::npos){

            pos += 1;
            contador += 1;
        }

        cout << "el patron " << i << " aparece "<< contador << " veces" << endl;

        // Reinicia las variables
        contador = 0;
        pos = 0;
    }
}


void buscar_patron(const string data, vector<string> patrones, int ID_patron, vector<int>& resultados){

    int contador = 0;
    int pos = 0;

    while ((pos = data.find(patrones.at(ID_patron),pos)) != string::npos){

        //Si encuentra una coincidencia, cambia la variable pos a la posición siguiente
        //de la última coincidencia y aumenta el contador en uno
        pos += 1;
        contador += 1;

    }
    

    // cout << "cont: " << contador << endl; 

    // Asigna los resultados al índice correspondiente al patron escaneado
    resultados[ID_patron] = contador;
}

int main(){


    int menu = 0;
    string nombre_archivo_patrones;
    string nombre_archivo_datos;
    nombre_archivo_datos = "texto.txt";
    nombre_archivo_patrones = "patrones.txt";

    //---------------------------------------------------------------------------------
    //---------------------------------- M E N U --------------------------------------
    //---------------------------------------------------------------------------------

    cout << "Este código se puede modificar para poder cambiar el nombre de los archivos de patrones y datos" << endl;
    // cout << "Si desea ingresar nombres de archivos personalizados, ingrese 1, sinó ingrese 0" << endl;
    // cout << "Nombres por defecto:" << endl;
    // cout << "Nombre archivo con patrones: " << nombre_archivo_patrones << endl;
    // cout << "Nombre archivo con datos: " << nombre_archivo_datos << endl;
    // cin >> menu;


    if(menu == 1){

        cout << "ingrese el nombre del archivo de donde se extraerán los patrones" << endl;
        cout << "recuerde ingresar el nombre completo incluida la extensión" << endl;

        cin >> nombre_archivo_patrones;

        cout << "ingrese el nombre del archivo con los datos a analizar" << endl;
        cout << "recuerde ingresar el nombre completo incluida la extensión" << endl;

        cin >> nombre_archivo_datos;
    }

    cout << "¿Desea realizar una ejecución mono hilo (0) o multi hilo (1)?" << endl;
    cin >> menu;


    //---------------------------------------------------------------------------------
    //-------------------------------FIN MENU------------------------------------------
    //---------------------------------------------------------------------------------

    //Inicio de medición de tiempo
    timeval t1,t2;
    gettimeofday(&t1,NULL);

    // Escanea el documento de patrones y establece la cantidad
    vector<string> patrones = ingresar_patrones(nombre_archivo_patrones);
    int cant_patrones = patrones.size();

    if(menu == 1){

        // EJECUCIÓN MULTI HILO

        ifstream text;
        string data;

        // Abre el archivo de datos y guarda la única linea que posee en una variable data
        text.open(nombre_archivo_datos);
        getline(text, data);


        
        // Crea un vector de hilos y uno de resultados, cada hilo y resultado se corresponde a un patrón
        vector<thread> hilos(cant_patrones);
        vector<int> resultados(cant_patrones);

        // Recorre todos los hilos y ejecuta la función buscar_patron en cada uno cambiando el patron de búsqueda
        for(int i = 0; i < cant_patrones; i++){

            hilos[i] = thread(buscar_patron, data, patrones, i, ref(resultados));
        
        }

        // Espera a que cierren todos los hilos y los cierra
        for(int i = 0; i < cant_patrones; i++){

            if (hilos[i].joinable()) {
                hilos[i].join();
            }
        }

        // Imprime resultados
        for (int i = 0; i < cant_patrones; i++) {
                cout << "el patron " << i << " aparece " << resultados[i] << " veces" << endl;
            }

    }else {
    
        // EJECUCIÓN MONO HILO
        buscar_patrones_mono_hilo(nombre_archivo_datos, patrones);

    }

    // Fin de medición de tiempo
    gettimeofday(&t2, NULL);
    cout << "El tiempo de ejecución fue: " << double(t2.tv_sec-t1.tv_sec) + double(t2.tv_usec - t1.tv_usec)/1000000 << endl;

    return 0;
}

