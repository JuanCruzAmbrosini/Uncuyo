package entities;

import java.util.ArrayList;
/*
Clase Person: Ésta clase es de suma importancia en este programa, ya que de ella heredan las clases "Cliente", "Técnico" e indirectamente, "Inspector". Los atributos comunes que tienen estas
clases son: nombre, DNI, sexo y edad.
 */
public abstract class Person {

    protected String name;
    protected String id;
    protected String sex;
    protected int age;
    /*
    Contructor de la clase (se deja vacío porque se gestiona la creación de personas en otros métodos)
     */
    public Person() {
    }

    /*
    Bloque de getters y setters
     */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String id() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String sex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int age() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    /*
    Tanto el método buscarTecnicoPorId como el método buscarClientePorId son bastante autoexplicativos, pero vale aclarar que se movieron a la clase "Compañía" porque sentía que esta última
    clase tenía mayor responsabilidad sobre estos 2 métodos, sin embargo, he decidido dejarlos en el código a modo demostrativo. También cabe mencionar que por la estructura del programa no
    es necesaria la creación de un cliente como entidad, esto se puede interpretar como un error de estructura. Es un dato que cabe mencionar y que es de relevancia, pero también se entiende
    que hacer un sistema de login con las herramientas que tenemos hasta este momento, se extiende por encima de este TP.
     */

    public Technician buscarTecnicoPorId (String idTecnico, ArrayList<Technician> listaTecnicos){

        Technician tecnicoBuscado  = new Technician();

        for (Technician tecnico : listaTecnicos){

            if (idTecnico.equalsIgnoreCase(tecnico.id())){

                tecnicoBuscado = tecnico;

            } else {

                System.out.println("No se encontraron técnicos con ese id");

            }

        }

        return tecnicoBuscado;

    }
    public Client buscarClientePorId (String idCliente, ArrayList<Client> listaClientes){

        Client clienteBuscado  = new Client();

        for (Client cliente : listaClientes){

            if (idCliente.equalsIgnoreCase(cliente.id())){

                clienteBuscado = cliente;

            } else {

                System.out.println("No se encontraron clientes con ese id");

            }

        }

        return clienteBuscado;

    }
}
