package entities;

/*
Clase "Review": Esta clase le da la posibilidad a un cliente de puntuar a un técnico y dejarle un comentario. Luego, el cliente podrá revisar las puntuaciones y los comentarios de otros
usuarios de la plataforma. Sus atributos son: El puntaje recibido y el comentario que desee dejar el usuario.
 */


public class Review {

    private int score;
    private String comment;


    /*
    Contructor de la clase (se deja vacío porque se gestiona la creación de reseñas en otros métodos).
     */

    public Review() {

    }


    /*
    Bloque de getters y setters.
     */

    public int score() {
        return score;
    }

    public Review setScore(int score) {
        this.score = score;
        return this;
    }

    public String comment() {
        return comment;
    }

    public Review setComment(String comment) {
        this.comment = comment;
        return this;
    }
}
