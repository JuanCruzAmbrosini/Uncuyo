package entities;

/*
Clase Inputs: Esta clase es la encargada de modelar los insumos de la empresa. Sus atributos son: La cantidad de litros de producto, un atributo de tipo booleano que indica si el técnico
necesitará herramientas o no y un String que indica si existe alguna otra indicación que deba ser tomada en cuenta.
 */

public class Inputs {

    private double productLiters;
    private boolean needsTools;
    private String others;


    /*
    Constructor de la clase "Inputs": En este constructor se define el paquete base de insumos que necesita un técnico para hacer la gran mayoría de los trabajos.
     */

    public Inputs() {

        this.productLiters = 10;
        this.needsTools = true;
        this.others = "none";

    }


    /*
    Bloque de getters y setters.
     */

    public double productLiters() {
        return productLiters;
    }

    public void setProductLiters(double productLiters) {
        this.productLiters = productLiters;
    }

    public boolean needsTools(boolean b) {
        return needsTools;
    }

    public void setNeedsTools(boolean needsTools) {
        this.needsTools = needsTools;
    }

    public String others() {
        return others;
    }

    public void setOthers(String others) {
        this.others = others;
    }


    /*
    Método toString, se usó, sobre todo, a la hora de hacer debugging y para probar como se cargaban los datos en la entidad.
     */

    @Override
    public String toString() {
        return "Inputs{" +
                "productLiters=" + productLiters +
                ", needsTools=" + needsTools +
                ", others='" + others + '\'' +
                '}';
    }
}
