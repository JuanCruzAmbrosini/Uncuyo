package entities;

/*
Clase "Technician": Esta clase va a ser la encargada de tomar órdenes y de realizar o rechazar los trabajos, hereda de la clase "Persona" por lo cual, hereda todos sus atributos, los atributos
añadidos son: su profesión, una lista con todas sus reseñas (uno a muchos) sus insumos y una lista con todas sus órdenes.
 */


import javax.print.attribute.standard.PrinterMakeAndModel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Technician extends Person{

    Scanner scanner = new Scanner(System.in).useDelimiter("\n");
    protected String profession;
    private ArrayList<Review> reviews;
    private Inputs inputs;
    private ArrayList<Order> orders;


    /*
    Constructor que le asigna al técnico un paquete de insumos base e inicializa todas las listas al momento de instanciar un objeto de tipo "Técnico".
     */

    public Technician() {

        this.inputs = new Inputs();
        this.reviews = new ArrayList<Review>();
        this.orders = new ArrayList<Order>();

    }


    /*
    Bloque de getters y setters.
     */

    public String profession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public Inputs inputs() {
        return inputs;
    }

    public ArrayList<Order> orders() {
        return orders;
    }

    public Technician setOrders(ArrayList<Order> orders) {
        this.orders = orders;
        return this;
    }

    public Technician setInputs(Inputs inputs) {
        this.inputs = inputs;
        return this;
    }

    public ArrayList<Review> reviews() {
        return reviews;
    }

    public Technician setReviews(ArrayList<Review> reviews) {
        this.reviews = reviews;
        return this;
    }

    /*
    Método mostrarOrdenesTecnico: Se encarga de mostrar todas las órdenes que posee un técnico en particular, a diferencia del método mostrarOrdenes en la clase "Company" que muestra la
    totalidad de las órdenes.
     */

    public void mostrarOrdenesTecnico (Technician tecnico){

        int contador = 0;

        for (Order orden : tecnico.orders){

            contador ++;

            System.out.println("-------------------------------------------------------------------------------------------");
            System.out.println("El id de la orden: " + contador + " es: " + orden.id() + "\nEl estado de la orden es: " + orden.orderState() + "\nEl tipo de la orden es: " + orden.orderType());
            System.out.println("-------------------------------------------------------------------------------------------");

        }

    }


    /*
    Método que le permite al técnico tomar o rechazar una orden. Al tomar una orden (siempre y cuando haya insumos en existencia), esta pasa a estar "aceptada" y le da la posibilidad al
    técnico de asignarle un presupuesto determinado. Una vez que la orden fué evaluada, se elimina de la lista de órdenes del técnico, para esto se utilizó un objeto de tipo "Iterator".
    También se usan instrucciones de return aunque el método sea de tipo void para salir antes del mismo.
     */

    public void tomarOrden(Technician tecnico, Company company) {
        String idOrden;
        String option;
        double presupuesto;

        System.out.println("Ingrese el id de la orden que desea tomar: ");
        idOrden = scanner.next();

        Iterator<Order> iterator = tecnico.orders.iterator();

        while (iterator.hasNext()) {
            Order orden = iterator.next();

            if (orden.id().equalsIgnoreCase(idOrden)) {
                System.out.println("¿Desea tomar la orden (1) o desea denegarla (2)?");
                option = scanner.next();

                if (option.equals("1")) {
                    if (company.inputs().size() < 1) {
                        System.out.println("No alcanzan los insumos para esta orden.");
                        return;
                    }

                    System.out.println("La orden ha sido aceptada.");
                    System.out.println("Ingrese su presupuesto para la orden: ");
                    presupuesto = scanner.nextDouble();

                    orden.setBudget(presupuesto);
                    orden.setOrderStateTechnisian("Tomada");
                    company.inputs().remove(1);

                    iterator.remove();

                } else if (option.equals("2")) {
                    System.out.println("La orden ha sido denegada.");
                } else {
                    System.out.println("Opción no válida.");
                }

                return;
            }
        }

        System.out.println("La orden seleccionada no existe.");
    }


    /*
    Método que permite mostrar los comentarios de un técnico en específico, así un usuario puede revisar lo que otros clientes piensan de ese técnico.
     */

    public static void mostrarMensajesReviews(ArrayList<Technician> tecnicos, String idTecnico){

        int contador = 0;

        for (Technician tecnico : tecnicos){

            if (idTecnico.equalsIgnoreCase(tecnico.id())){

                for(Review review : tecnico.reviews()){

                    contador ++;

                    System.out.println("-------------------------------------------------------------------------------------------");
                    System.out.println("Comentario N° " + contador + ": " + review.comment());
                    System.out.println("-------------------------------------------------------------------------------------------");

                }

            }

        }

    }

}
