document.addEventListener('DOMContentLoaded', ()=>{

    const formulario = document.querySelector('.formulario');
    const respuesta = document.querySelector('#parrafo');

    respuesta.style.display = 'none';
    
    formulario.addEventListener('submit', (e)=>{
        e.preventDefault();

        const nombre = document.querySelector('#nombre').value;
        const password = document.querySelector('#password').value;
        
        if (nombre === "" && password === ""){
            respuesta.style.display = 'block';
            respuesta.textContent = 'Debe rellenar todos los campos';
            respuesta.style.backgroundColor = 'red';
        } else { 
            respuesta.style.display = 'block';
            respuesta.textContent = 'Formulario enviado correctamente';
            respuesta.style.backgroundColor = 'green';
        }
    })
})